<?php
  //$dbCon = mysqli_connect("localhost", "root", "password", "learnlearn") or die(mysqli_error());

  $dsn = "mysql:host=localhost;dbname=grandma_life2";
        $user = "root";
        $password = "";
        $options = null;


 ?>
